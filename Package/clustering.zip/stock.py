import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from pandas import ExcelWriter
from sqlalchemy import create_engine


sns.set(style="white")
plt.rcParams["font.family"] = 'HYSinMyeongJo-Medium'
plt.rcParams["font.size"] = 12
code_df = pd.read_html('http://kind.krx.co.kr/corpgeneral/corpList.do?method=download&searchType=13', header=0)[0]
code_df.종목코드 = code_df.종목코드.map('{:06d}'.format)
code_df = code_df[['회사명', '종목코드']]
code_df = code_df[['회사명','종목코드']]
code_df = code_df.rename(columns={'회사명': 'name', '종목코드': 'code'})
priceDic={}

namelist=code_df['name']

def get_url(item_name, code_df): #네이버에서 종목별 페이지 url 구하기
    code = code_df.query("name=='{}'".format(item_name))['code'].to_string(index=False) # 한국거래소(krx)에서 종목코드 가져오기
    url = 'http://finance.naver.com/item/sise_day.nhn?code={code}'.format(code=code) #네이버에서 해당 종목페이지 url 구하기
    print("요청 URL = {}".format(url))
    return url


def save_stock(): #네이버url 종목의 일별 데이터를 저장
    n=0
    for name in namelist:
        if(n<5):
            item_name=name
            url=get_url(item_name,code_df)
            df=pd.DataFrame()
            for page in range(1, 5):
                pg_url = '{url}&page={page}'.format(url=url, page=page)
                df = df.append(pd.read_html(pg_url, header=0)[0],     ignore_index=True)
            pricelist=df['종가']
            priceDic[item_name]=pricelist
            n+=1
    

    All_Price=pd.DataFrame(priceDic)
    All_Price.index=df['날짜']
    All_Price=All_Price.dropna(how='all')
    corr = All_Price.corr(method = 'pearson')
    writer = ExcelWriter('종가.xlsx')
    corr.to_excel(writer,'Sheet1')
    writer.save()

if __name__ == '__main__':
    save_stock()
