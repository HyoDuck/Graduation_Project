import cluster1

if __name__ == '__main__':
    test = cluster1.clustering(excel='C:/data/1000.xlsx', y=1.5)
    print(test)

    this_one = ['동작', '합니까']
    print(this_one)